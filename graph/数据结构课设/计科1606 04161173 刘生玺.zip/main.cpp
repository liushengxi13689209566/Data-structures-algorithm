/*************************************************************************
	> File Name: main.cpp
	> Author: 
	> Mail: 
	> Created Time: 2018年01月02日 星期二 13时16分17秒
 ************************************************************************/

#include<iostream>
#include"myhead.h"
using namespace std;
int main(void)
{
    Graph  gg ;
	gg.create();
    gg.GraphMenu() ;
    return 0;
}